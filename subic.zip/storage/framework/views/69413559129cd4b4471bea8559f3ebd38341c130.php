<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Subic Truck Mall</title>
    <link href="assets2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets2/css/style.css')); ?>">
    <script src="assets2/js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <div class="wrapper">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="row row-top">
                    <div class="col-md-2">
                        <img src="assets2/images/Top/logo.png" alt="">
                    </div>
                    <div class="col-md-7">
                        <div class="row mb-2">
                            <input type="text" class="inp-search" placeholder="Search">
                        </div>
                        <div class="row">
                            <div class="top-icon"></div>
                            <div class="top-icon"></div>
                            <div class="top-icon"></div>
                            <div class="top-icon"></div>
                            <div class="top-icon"></div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <p>
                            <img src="assets2/images/Top/account-icon.png" class="account-icon" alt=""><span class="lbl_login">LOGIN</span>
                            <img src="assets2/images/Top/cart-icon.png" class="float-end" alt="">
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
<?php /**PATH C:\Users\Real\Documents\Laravel\subic\resources\views/pages/landing.blade.php ENDPATH**/ ?>